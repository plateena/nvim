local M = {}

local function matches_query(text, query)
  local haystack = text:lower()
  for word in query:lower():gmatch("%S+") do
    if not haystack:find(word, 1, true) then
      return false
    end
  end
  return true
end

function M.open(chapters, tag_chapter)
  if #chapters == 0 then
    vim.notify("No chapter files found.", vim.log.levels.INFO)
    return
  end

  local width = math.max(30, math.min(78, math.floor(vim.o.columns * 0.85)))
  local list_height = math.min(14, math.max(5, #chapters))
  local row = math.max(0, math.floor((vim.o.lines - (list_height + 3)) / 2))
  local col = math.max(0, math.floor((vim.o.columns - width) / 2))

  local prompt_buf = vim.api.nvim_create_buf(false, true)
  local list_buf = vim.api.nvim_create_buf(false, true)

  vim.bo[prompt_buf].buftype = "prompt"
  vim.bo[prompt_buf].bufhidden = "wipe"
  vim.bo[list_buf].buftype = "nofile"
  vim.bo[list_buf].bufhidden = "wipe"
  vim.bo[list_buf].swapfile = false
  vim.bo[list_buf].modifiable = false

  local prompt_win = vim.api.nvim_open_win(prompt_buf, true, {
    relative = "editor",
    width = width,
    height = 1,
    row = row,
    col = col,
    style = "minimal",
    border = "rounded",
    title = " Chapters (<CR>: Open | <C-t>: Tag) ",
    title_pos = "center",
  })

  local list_win = vim.api.nvim_open_win(list_buf, false, {
    relative = "editor",
    width = width,
    height = list_height,
    row = row + 3,
    col = col,
    style = "minimal",
    border = "rounded",
  })

  vim.wo[list_win].cursorline = true

  local filtered = {}
  local closed = false
  local augroup = vim.api.nvim_create_augroup("MypluginChapterPicker" .. prompt_buf, { clear = true })

  local function close_picker()
    if closed then
      return
    end
    closed = true

    pcall(vim.cmd, "stopinsert")
    pcall(vim.api.nvim_del_augroup_by_id, augroup)

    if vim.api.nvim_win_is_valid(prompt_win) then
      vim.api.nvim_win_close(prompt_win, true)
    end
    if vim.api.nvim_win_is_valid(list_win) then
      vim.api.nvim_win_close(list_win, true)
    end

    if vim.api.nvim_buf_is_valid(prompt_buf) then
      vim.api.nvim_buf_delete(prompt_buf, { force = true })
    end
    if vim.api.nvim_buf_is_valid(list_buf) then
      vim.api.nvim_buf_delete(list_buf, { force = true })
    end
  end

  local function selected_chapter()
    if not vim.api.nvim_win_is_valid(list_win) or #filtered == 0 then
      return nil
    end

    local cursor = vim.api.nvim_win_get_cursor(list_win)
    return filtered[cursor[1]]
  end

  local function update_list(query)
    filtered = {}

    for _, chapter in ipairs(chapters) do
      if query == "" or matches_query(chapter.display, query) then
        table.insert(filtered, chapter)
      end
    end

    local lines = {}
    for _, chapter in ipairs(filtered) do
      table.insert(lines, " " .. chapter.display)
    end

    if #lines == 0 then
      lines = { " (No matching chapters)" }
    end

    vim.bo[list_buf].modifiable = true
    vim.api.nvim_buf_set_lines(list_buf, 0, -1, false, lines)
    vim.bo[list_buf].modifiable = false

    if vim.api.nvim_win_is_valid(list_win) then
      vim.api.nvim_win_set_cursor(list_win, { 1, 0 })
    end
  end

  local function open_current()
    local chapter = selected_chapter()
    close_picker()

    if chapter then
      vim.cmd.edit(vim.fn.fnameescape(chapter.path))
    end
  end

  local function tag_current()
    local chapter = selected_chapter()
    if not chapter then
      return
    end

    close_picker()
    tag_chapter(chapter.path, function()
      vim.schedule(function()
        require("myplugin").jump_to_chapter()
      end)
    end)
  end

  local function move_selection(delta)
    if #filtered == 0 or not vim.api.nvim_win_is_valid(list_win) then
      return
    end

    local current = vim.api.nvim_win_get_cursor(list_win)[1]
    local next_index = ((current - 1 + delta) % #filtered) + 1
    vim.api.nvim_win_set_cursor(list_win, { next_index, 0 })
  end

  vim.api.nvim_create_autocmd({ "TextChangedI", "TextChanged" }, {
    group = augroup,
    buffer = prompt_buf,
    callback = function()
      local lines = vim.api.nvim_buf_get_lines(prompt_buf, 0, 1, false)
      update_list(lines[1] or "")
    end,
  })

  local opts = { buffer = prompt_buf, silent = true }
  vim.keymap.set({ "i", "n" }, "<CR>", open_current, opts)
  vim.keymap.set({ "i", "n" }, "<C-t>", tag_current, opts)
  vim.keymap.set({ "i", "n" }, "<Esc>", close_picker, opts)
  vim.keymap.set({ "i", "n" }, "<C-c>", close_picker, opts)
  vim.keymap.set({ "i", "n" }, "<Down>", function() move_selection(1) end, opts)
  vim.keymap.set({ "i", "n" }, "<Up>", function() move_selection(-1) end, opts)
  vim.keymap.set("i", "<C-n>", function() move_selection(1) end, opts)
  vim.keymap.set("i", "<C-p>", function() move_selection(-1) end, opts)
  vim.keymap.set("i", "<C-j>", function() move_selection(1) end, opts)
  vim.keymap.set("i", "<C-k>", function() move_selection(-1) end, opts)

  update_list("")
  vim.cmd.startinsert()
end

return M
