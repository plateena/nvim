local M = {}

local function read_lines(filepath, limit)
  local lines = vim.fn.readfile(filepath, "", limit or 0)
  return lines or {}
end

function M.parse(lines)
  for i = 1, math.min(5, #lines) do
    local tag_string = lines[i]:match("^<!%-%-%s*tags:%s*(.-)%s*%-%->")
    if tag_string then
      local tags = {}
      for tag in tag_string:gmatch("[^,]+") do
        local clean = vim.trim(tag):lower()
        if clean ~= "" and not vim.tbl_contains(tags, clean) then
          table.insert(tags, clean)
        end
      end
      return tags, i
    end
  end

  return {}, nil
end

function M.get(filepath)
  return M.parse(read_lines(filepath, 20))
end

function M.save(filepath, new_tags)
  local bufnr = vim.fn.bufnr(vim.fn.fnamemodify(filepath, ":p"))
  local is_loaded = bufnr ~= -1 and vim.api.nvim_buf_is_loaded(bufnr)

  local lines
  if is_loaded then
    lines = vim.api.nvim_buf_get_lines(bufnr, 0, -1, false)
  else
    lines = read_lines(filepath)
  end

  local _, existing_index = M.parse(lines)
  local tag_line = #new_tags > 0
      and ("<!-- tags: " .. table.concat(new_tags, ", ") .. " -->")
    or nil

  if existing_index then
    if tag_line then
      lines[existing_index] = tag_line
    else
      table.remove(lines, existing_index)
      if lines[existing_index] == "" then
        table.remove(lines, existing_index)
      end
    end
  elseif tag_line then
    table.insert(lines, 1, "")
    table.insert(lines, 1, tag_line)
  end

  if is_loaded then
    local original_modifiable = vim.bo[bufnr].modifiable
    local ok, err = pcall(function()
      vim.bo[bufnr].modifiable = true
      vim.api.nvim_buf_set_lines(bufnr, 0, -1, false, lines)

      vim.api.nvim_buf_call(bufnr, function()
        vim.cmd("silent write")
      end)
    end)

    if not ok then
      vim.bo[bufnr].modifiable = original_modifiable
      vim.notify("myplugin: could not save tags: " .. tostring(err), vim.log.levels.ERROR)
      return false
    end

    -- BufWritePost lock handling may have run during :write. Reapply the
    -- intended state so removing the locked tag unlocks the buffer.
    vim.bo[bufnr].modifiable = not vim.tbl_contains(new_tags, "locked")
  else
    local result = vim.fn.writefile(lines, filepath)
    if result ~= 0 then
      vim.notify("myplugin: could not write " .. filepath, vim.log.levels.ERROR)
      return false
    end
  end

  return true
end

function M.toggle(filepath, tag_name)
  local clean = vim.trim(tag_name):lower()
  if clean == "" then
    return nil
  end

  local tags = M.get(filepath)
  local index

  for i, tag in ipairs(tags) do
    if tag == clean then
      index = i
      break
    end
  end

  if index then
    table.remove(tags, index)
  else
    table.insert(tags, clean)
  end

  if not M.save(filepath, tags) then
    return nil
  end

  return tags
end

return M
