local M = {}

local function read_metadata(filepath, fallback)
  local lines = vim.fn.readfile(filepath, "", 20) or {}
  local tags = require("myplugin.tags").parse(lines)
  local title = fallback

  for _, line in ipairs(lines) do
    local heading = line:match("^#%s+(.+)")
    if heading then
      title = heading
      break
    end
  end

  return title, tags
end

function M.resolve_dir(config, start_path)
  if vim.fn.isabsolutepath(config.dir) == 1 then
    local absolute = vim.fs.normalize(config.dir)
    return vim.fn.isdirectory(absolute) == 1 and absolute or nil
  end

  local path = start_path
  if not path or path == "" then
    path = vim.api.nvim_buf_get_name(0)
  end
  if path == "" then
    path = vim.fn.getcwd()
  elseif vim.fn.isdirectory(path) == 0 then
    path = vim.fs.dirname(path)
  end

  local found = vim.fs.find(config.dir, {
    upward = true,
    path = path,
    type = "directory",
  })

  if #found > 0 then
    return vim.fs.normalize(found[1])
  end

  local cwd_path = vim.fs.normalize(vim.fn.getcwd() .. "/" .. config.dir)
  if vim.fn.isdirectory(cwd_path) == 1 then
    return cwd_path
  end

  return nil
end

function M.is_inside(filepath, directory)
  filepath = vim.fs.normalize(filepath)
  directory = vim.fs.normalize(directory)

  return filepath == directory or vim.startswith(filepath, directory .. "/")
end

local function is_valid_file(filename, config)
  if filename:sub(1, 1) == "." then
    return false
  end

  local extension = filename:match("%.([^.]+)$")
  if not extension then
    return config.allow_extensionless
  end

  return vim.tbl_contains(config.extensions, extension:lower())
end

function M.list(directory, config)
  local chapters = {}

  for filename, entry_type in vim.fs.dir(directory) do
    if entry_type == "file" and is_valid_file(filename, config) then
      local filepath = directory .. "/" .. filename
      local title, tags = read_metadata(filepath, filename)
      local badge = #tags > 0 and ("  [" .. table.concat(tags, ", ") .. "]") or ""
      local display

      if title ~= filename then
        display = string.format("%s  (%s)%s", title, filename, badge)
      else
        display = filename .. badge
      end

      table.insert(chapters, {
        filename = filename,
        title = title,
        tags = tags,
        path = filepath,
        display = display,
      })
    end
  end

  table.sort(chapters, function(a, b)
    return a.filename:lower() < b.filename:lower()
  end)

  return chapters
end

return M
