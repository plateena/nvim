local M = {}

local config
local is_setup = false

local function notify_tags(tags)
  vim.notify("Tags: " .. (#tags > 0 and table.concat(tags, ", ") or "none"))
end

function M.toggle_tag_on_file(filepath, tag_name)
  if not filepath or filepath == "" then
    vim.notify("myplugin: no chapter file specified.", vim.log.levels.WARN)
    return nil
  end

  local tags = require("myplugin.tags").toggle(filepath, tag_name)
  if tags then
    notify_tags(tags)
  end
  return tags
end

function M.tag_chapter(filepath, on_complete)
  filepath = filepath or vim.api.nvim_buf_get_name(0)

  if filepath == "" or vim.fn.filereadable(filepath) == 0 then
    vim.notify("Open or select a valid chapter file first.", vim.log.levels.WARN)
    return
  end

  local tag_module = require("myplugin.tags")
  local current_tags = tag_module.get(filepath)
  local choices = vim.deepcopy(config.preset_tags)

  for _, tag in ipairs(current_tags) do
    if not vim.tbl_contains(choices, tag) then
      table.insert(choices, tag)
    end
  end
  table.insert(choices, "+ Add custom tag...")

  vim.ui.select(choices, {
    prompt = "Toggle Chapter Tag:",
    format_item = function(item)
      if item == "+ Add custom tag..." then
        return item
      end

      local active = vim.tbl_contains(current_tags, item)
      return string.format("[%s] %s", active and "x" or " ", item)
    end,
  }, function(choice)
    if not choice then
      return
    end

    local function complete(tag_name)
      local updated = M.toggle_tag_on_file(filepath, tag_name)
      if updated and on_complete then
        on_complete(updated)
      end
    end

    if choice == "+ Add custom tag..." then
      vim.ui.input({ prompt = "New tag name: " }, function(input)
        if input and vim.trim(input) ~= "" then
          complete(input)
        end
      end)
    else
      complete(choice)
    end
  end)
end

function M.jump_to_chapter()
  local chapters_module = require("myplugin.chapters")
  local directory = chapters_module.resolve_dir(config)

  if not directory then
    vim.notify("myplugin: could not find '" .. config.dir .. "' directory.", vim.log.levels.WARN)
    return
  end

  local chapters = chapters_module.list(directory, config)
  if #chapters == 0 then
    vim.notify("No chapter files found in " .. directory, vim.log.levels.INFO)
    return
  end

  require("myplugin.picker").open(chapters, M.tag_chapter)
end

function M.setup(opts)
  if is_setup then
    if opts then
      vim.notify("myplugin: setup has already run; restart Neovim to change configuration.", vim.log.levels.WARN)
    end
    return
  end

  config = require("myplugin.config").setup(opts)
  is_setup = true

  require("myplugin.lock").setup(config, require("myplugin.chapters"))

  vim.api.nvim_create_user_command("ChapterJump", function()
    M.jump_to_chapter()
  end, {
    desc = "Search, tag, and open a manuscript chapter",
  })

  vim.api.nvim_create_user_command("ChapterTag", function(command)
    local filepath = vim.api.nvim_buf_get_name(0)

    if command.args ~= "" then
      M.toggle_tag_on_file(filepath, command.args)
    else
      M.tag_chapter(filepath)
    end
  end, {
    nargs = "?",
    complete = function()
      return config.preset_tags
    end,
    desc = "Toggle a tag on the current chapter",
  })
end

return M
