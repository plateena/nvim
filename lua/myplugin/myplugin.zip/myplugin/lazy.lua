-- Copy this file to lua/plugins/manuscript.lua in your Neovim config.
return {
  {
    dir = vim.fn.stdpath("config") .. "/local/myplugin",
    name = "myplugin",
    lazy = false,
    config = function()
      require("myplugin").setup({
        dir = "manuscript",
        extensions = { "md", "txt" },
        allow_extensionless = true,
        preset_tags = { "draft", "reviewed", "locked", "publish" },
      })
    end,
  },
}
