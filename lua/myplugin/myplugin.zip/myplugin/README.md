# myplugin — Manuscript Chapter Manager

A small Neovim plugin for finding manuscript chapters, searching by title or tags,
toggling chapter tags, and protecting chapters tagged `locked`.

## Requirements

- Neovim 0.9 or newer
- `vim.ui.select` and `vim.ui.input` (built into Neovim)

## Installation with lazy.nvim

Place this repository at:

```text
~/.config/nvim/local/myplugin/
```

The directory should contain this plugin's `lua/` directory and `README.md`.

Create `lua/plugins/manuscript.lua`:

```lua
return {
  {
    dir = vim.fn.stdpath("config") .. "/local/myplugin",
    name = "myplugin",
    lazy = false,
    config = function()
      require("myplugin").setup({
        dir = "manuscript",
        extensions = { "md", "txt" },
        allow_extensionless = true,
        preset_tags = { "draft", "reviewed", "locked", "publish" },
      })
    end,
  },
}
```

Restart Neovim and run `:Lazy` to confirm that `myplugin` is loaded.

## Configuration

All options are optional.

```lua
require("myplugin").setup({
  -- Directory name searched for from the current file's directory upward.
  dir = "manuscript",

  -- Accepted file extensions. A leading dot is optional.
  extensions = { "md", "txt" },

  -- Whether files without an extension should be listed.
  allow_extensionless = true,

  -- Tags shown in the tag selector and command completion.
  preset_tags = { "draft", "reviewed", "locked", "publish" },
})
```

An absolute `dir` path is also supported.

## Commands

| Command | Description |
| --- | --- |
| `:ChapterJump` | Open the searchable chapter picker |
| `:ChapterTag` | Open the tag selector for the current file |
| `:ChapterTag draft` | Toggle `draft` on the current file |
| `:ChapterTag locked` | Toggle the read-only `locked` tag |

## Picker keys

| Key | Action |
| --- | --- |
| `<CR>` | Open the selected chapter |
| `<C-t>` | Open the tag selector for the selected chapter |
| `<C-n>` / `<C-p>` | Move selection |
| `<C-j>` / `<C-k>` | Move selection |
| `<Down>` / `<Up>` | Move selection |
| `<Esc>` / `<C-c>` | Close the picker |

Search matches all whitespace-separated query words against the chapter's displayed
title, filename, and tags.

## Tag format

Tags are stored in an HTML comment within the first five lines of a chapter:

```markdown
<!-- tags: draft, reviewed -->

# Chapter One
```

Tags are normalized to lowercase and duplicate tags are removed.

## Locked chapters

A chapter containing the `locked` tag is made non-modifiable when opened and after
it is written. Use `:ChapterTag locked` to remove the tag and unlock the current
chapter.

The lock is an editor-level safeguard, not filesystem permissions or security
protection.
